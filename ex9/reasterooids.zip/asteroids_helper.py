#############################################################################
# FILE : ship.py
# WRITER : Yoav Galtzur, yoav.galtzur, 203372511
# WRITER : Yosef Yehoshua, yosef12345, 302818513
# EXERCISE : intro2cs ex9 2015-2016
# DESCRIPTION : ???
#############################################################################
from screen import Screen
import math

SCREEN_MAX_X = Screen.SCREEN_MAX_X
SCREEN_MAX_Y = Screen.SCREEN_MAX_Y
SCREEN_MIN_X = Screen.SCREEN_MIN_X
SCREEN_MIN_Y = Screen.SCREEN_MIN_Y
LENGTH_X_AXIS = SCREEN_MAX_X - SCREEN_MIN_X
LENGTH_Y_AXIS = SCREEN_MAX_Y - SCREEN_MIN_Y


class Helper:
    """
    HELPER DESCRIPTION
    """

    def set_postion_on_axis(self, pos, speed, axis_min, axis_length):
        """
        returns new position of an object in the gane 'Asteroids'
        :param pos_x: old pos in X axis
        :param pos_y: old pos in Y axis
        :param speed_x: speed in X axis
        :param speed_y: speed in Y axis
        :return: tuple of the new position
        """
        dis_from_min = (speed + pos - axis_min) % axis_length
        new_pos = dis_from_min + axis_min
        return new_pos

    def angle_to_radians(self, angle):
        """
        :param angle: float
        :return: the angle in radians
        """
        return math.radians(angle)

