#############################################################################
# FILE : ship.py
# WRITER : Yoav Galtzur, yoav.galtzur, 203372511
# WRITER : Yosef Yehoshua, yosef12345, 302818513
# EXERCISE : intro2cs ex9 2015-2016
# DESCRIPTION : ???
#############################################################################
import random
from asteroids_helper import Helper
import math
import ship

LIVE_SPAN = 200
TORPEDO_RADIUS = 4
SPEED_FACTOR = 2

class Torpedo:
    """
    A class representing a ship in the game 'Asteroids'
    """

    def __init__(self, angle, pos_x, pos_y, speed_x, speed_y, SCREEN_MAX_X, SCREEN_MAX_Y, SCREEN_MIN_X, SCREEN_MIN_Y):
        """
        DESCRIPTION
        :return:
        """
        self.__help = Helper()
        self.__angle = angle
        self.__speed_x = speed_x
        self.__speed_y = speed_y
        self.__radius = TORPEDO_RADIUS
        self.__lives_span = LIVE_SPAN
        self.screen_max_x = SCREEN_MAX_X
        self.screen_max_y = SCREEN_MAX_Y
        self.screen_min_x = SCREEN_MIN_X
        self.screen_min_y = SCREEN_MIN_Y
        self.length_x_axis = SCREEN_MAX_X - SCREEN_MIN_X
        self.length_y_axis = SCREEN_MAX_Y - SCREEN_MIN_Y
        self.__pos_x = pos_x
        self.__pos_y = pos_y
        self.set_speed()

    def get_pos_x(self):
        """
        :return: position of the ship on the X (horizontal) axis
        """
        return self.__pos_x

    def get_pos_y(self):
        """
        :return: position of the ship on the Y (vertical) axis
        """
        return self.__pos_y

    def get_lives(self):
        """
        :return: number of lives of the ship
        """
        return self.__lives

    def get_angle(self):
        """
        :return: angle of the ship
        """
        return self.__angle

    def get_radius(self):
        """
        :return: radius of the ship
        """
        return self.__radius

    def set_position(self):
        """
        Sets new position to the ship, according to its speed and former pos
        """
        self.__pos_x = self.__help.set_postion_on_axis(self.__pos_x, self.__speed_x, self.screen_min_x, self.length_x_axis)
        self.__pos_y = self.__help.set_postion_on_axis(self.__pos_y, self.__speed_y, self.screen_min_y, self.length_y_axis)

    def set_speed(self):
        angle = self.__help.angle_to_radians(self.__angle)
        self.__speed_x += SPEED_FACTOR * math.cos(angle)
        self.__speed_y += SPEED_FACTOR * math.sin(angle)

    def lose_life(self):
        self.__lives_span -= 1

    def is_dead(self):
        if self.__lives_span == 0:
            return True
        else:
            return False

