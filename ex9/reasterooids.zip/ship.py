#############################################################################
# FILE : ship.py
# WRITER : Yoav Galtzur, yoav.galtzur, 203372511
# WRITER : Yosef Yehoshua, yosef12345, 302818513
# EXERCISE : intro2cs ex9 2015-2016
# DESCRIPTION : ???
#############################################################################
import random
from asteroids_helper import Helper
import math

NO_OF_LIVES = 3
SHIP_RADIUS = 1

class Ship:
    """
    A class representing a ship in the game 'Asteroids'
    """

    def __init__(self, SCREEN_MAX_X, SCREEN_MAX_Y, SCREEN_MIN_X, SCREEN_MIN_Y):
        """
        DESCRIPTION
        :return:
        """
        self.__help = Helper()

        self.__angle = 0

        self.__speed_x = 0
        self.__speed_y = 0
        self.__lives = NO_OF_LIVES
        self.screen_max_x = SCREEN_MAX_X
        self.screen_max_y = SCREEN_MAX_Y
        self.screen_min_x = SCREEN_MIN_X
        self.screen_min_y = SCREEN_MIN_Y
        self.length_x_axis = SCREEN_MAX_X - SCREEN_MIN_X
        self.length_y_axis = SCREEN_MAX_Y - SCREEN_MIN_Y
        self.__radius = SHIP_RADIUS
        self.__pos_x = random.randint(self.screen_min_x, self.screen_max_x)  # CHECK IF SCREEN SIZE IS ALWAYS INT
        self.__pos_y = random.randint(self.screen_min_y, self.screen_max_y)  # CHECK IF SCREEN SIZE IS ALWAYS INT

    def get_pos_x(self):
        """
        :return: position of the ship on the X (horizontal) axis
        """
        return self.__pos_x

    def get_pos_y(self):
        """
        :return: position of the ship on the Y (vertical) axis
        """
        return self.__pos_y

    def get_lives(self):
        """
        :return: number of lives of the ship
        """
        return self.__lives

    def get_angle(self):
        """
        :return: angle of the ship
        """
        return self.__angle

    def get_radius(self):
        """
        :return: radius of the ship
        """
        return self.__radius

    def set_position(self):
        """
        Sets new position to the ship, according to its speed and former pos
        """
        self.__pos_x = self.__help.set_postion_on_axis(self.__pos_x, self.__speed_x, self.screen_min_x, self.length_x_axis)
        self.__pos_y = self.__help.set_postion_on_axis(self.__pos_y, self.__speed_y, self.screen_min_y, self.length_y_axis)



    def set_angle(self, new_angle):
        """
        Sets new angle to the ship
        """
        self.__angle += new_angle

    def get_speed_x(self):
        return self.__speed_x

    def get_speed_y(self):
        return self.__speed_y

    def accelerate(self):
        """
        Sets new speed to the ship
        """
        angle = self.__help.angle_to_radians(self.__angle)
        self.__speed_x = self.__speed_x + math.cos(angle)
        self.__speed_y = self.__speed_y + math.sin(angle)

    def lose_life(self):
        self.__lives -= 1

    def is_dead(self):
        if self.__lives == 0:
            return True
        else:
            return False
