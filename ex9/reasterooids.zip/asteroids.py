#############################################################################
# FILE : asteroids.py
# WRITER : Yoav Galtzur, yoav.galtzur, 203372511
# WRITER : Yosef Yehoshua, yosef12345, 302818513
# EXERCISE : intro2cs ex9 2015-2016
# DESCRIPTION : ???
#############################################################################
import random
from asteroids_helper import Helper
import math


SIZE_FACTOR = 10
NORMAL_FACTOR = 5
MIN_SPEED = 1
TOP_SPEED = 3
MIN_ANGLE = 0
MAX_ANGLE = 306


class Asteroid:
    """
    A class representing an asteroid in the game 'Asteroids'
    """

    def __init__(self, size, SCREEN_MAX_X, SCREEN_MAX_Y, SCREEN_MIN_X, SCREEN_MIN_Y):
        """

        :param board_size:
        :param SCREEN_MAX_X:
        :param SCREEN_MAX_Y:
        :param SCREEN_MIN_X:
        :param SCREEN_MIN_Y:
        :return:
        """
        self.__help = Helper()
        self.__angle = random.uniform(MIN_ANGLE, MAX_ANGLE)
        self.__speed_x = random.randint(MIN_SPEED, TOP_SPEED)
        self.__speed_y = random.randint(MIN_SPEED, TOP_SPEED)
        self.__size = size
        self.screen_max_x = SCREEN_MAX_X
        self.screen_max_y = SCREEN_MAX_Y
        self.screen_min_x = SCREEN_MIN_X
        self.screen_min_y = SCREEN_MIN_Y
        self.length_x_axis = SCREEN_MAX_X - SCREEN_MIN_X
        self.length_y_axis = SCREEN_MAX_Y - SCREEN_MIN_Y
        self.__radius = self.__size * SIZE_FACTOR - NORMAL_FACTOR
        self.__pos_x = random.randint(self.screen_min_x, self.screen_max_x)  # CHECK IF SCREEN SIZE IS ALWAYS INT
        self.__pos_y = random.randint(self.screen_min_y, self.screen_max_y)  # CHECK IF SCREEN SIZE IS ALWAYS INT

    def get_pos_x(self):
        """
        :return: position of the ship on the X (horizontal) axis
        """
        return self.__pos_x

    def get_pos_y(self):
        """
        :return: position of the ship on the Y (vertical) axis
        """
        return self.__pos_y

    def get_angle(self):
        return self.__angle

    def get_size(self):
        """
        :return: number of lives of the ship
        """
        return self.__size

    def set_position(self):
        """
        Sets new position to the ship, according to its speed and former pos
        """

        self.__pos_x = self.__help.set_postion_on_axis\
            (self.__pos_x, self.__speed_x, self.screen_min_x,
             self.length_x_axis)
        self.__pos_y = self.__help.set_postion_on_axis\
            (self.__pos_y, self.__speed_y, self.screen_min_y,
             self.length_y_axis)

    def set_speed(self, new_speed):
        """
        Sets new speed to the ship
        """
        pass

    def has_intersection(self, obj):
        pos_x = math.pow(self.__pos_x - obj.get_pos_x(), 2)
        pos_y = math.pow(self.__pos_y - obj.get_pos_y(), 2)
        distance = math.sqrt(pos_x + pos_y)
        tot_radius = self.__radius + obj.get_radius()
        if distance <= tot_radius:
            return True
        else:
            return False
