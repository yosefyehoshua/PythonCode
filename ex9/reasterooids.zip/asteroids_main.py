from screen import Screen
from ship import Ship
from asteroids import Asteroid
import sys
import copy
from torpedo import Torpedo

DEFAULT_ASTEROIDS_NUM = 5
ASTEROID_START_SIZE = 3
TITLE = "shit happens"
DEAD_MSG = "you're Dead"
VICTORY_TITLE = "i can't believe it!"
VICTORY_MSG = "you've won!"
LOSE_LIFE_MSG = "you've lost one life..."
ANGLE = 7
MAX_TORPEDO = 15
MIN_SPLIT_SIZE = 1

class GameRunner:
    """
    Add DESCRIPTION
    """

    def __init__(self, asteroids_amnt):
        self._screen = Screen()
        self.screen_max_x = Screen.SCREEN_MAX_X
        self.screen_max_y = Screen.SCREEN_MAX_Y
        self.screen_min_x = Screen.SCREEN_MIN_X
        self.screen_min_y = Screen.SCREEN_MIN_Y
        self.ship = Ship(self.screen_max_x, self.screen_max_y, self.screen_min_x, self.screen_min_y)
        self.asteroids_amnt = asteroids_amnt
        self.asteroids_dic = {}
        self.create_asteroids()
        self.__torpedoes_list = []
        self.__damaged_asteroids = []
        self.__score = 0
        self.__max_asteroid_id = 0

    def create_asteroids(self):
        """
        assigns new asteroids to the
        """
        for count in range(self.asteroids_amnt):
            # create new asteroid and assign it to the dictionary
            self.asteroids_dic[count] = Asteroid(ASTEROID_START_SIZE,
            self.screen_max_x, self.screen_max_y, self.screen_min_x, self.screen_min_y)
            self._screen.register_asteroid(count, self.asteroids_dic[count].get_size())
        self.__max_asteroid_id = count   # TODO count or maybe something else??

    def run(self):
        self._do_loop()
        self._screen.start_screen()

    def _do_loop(self):
        # You don't need to change this method!
        self._game_loop()

        # Set the timer to go off again
        self._screen.update()
        self._screen.ontimer(self._do_loop,5)

    def move_ship(self):
        if self._screen.is_left_pressed():
            self.ship.set_angle(ANGLE)
        elif self._screen.is_right_pressed():
            self.ship.set_angle(-ANGLE)
        if self._screen.is_up_pressed():
            self.ship.accelerate()
        self.ship.set_position()

    def create_torpedo(self):
        if len(self.__torpedoes_list) < MAX_TORPEDO:
            new_torpedo = Torpedo(self.ship.get_angle(), self.ship.get_pos_x(), self.ship.get_pos_y(), self.ship.get_speed_x(), self.ship.get_speed_y(), self.screen_max_x, self.screen_max_y, self.screen_min_x, self.screen_min_y)
            self.__torpedoes_list.append(new_torpedo)
            self._screen.register_torpedo(new_torpedo)

    def torpedo_manager(self, torpedo, id, asteroid):
        if torpedo.is_dead():
            self.__torpedoes_list.remove(torpedo)
            self._screen.unregister_torpedo(torpedo)
        elif asteroid.has_intersection(torpedo):
            self._screen.unregister_asteroid(id)
            self.__damaged_asteroids.append(asteroid)
            self.__torpedoes_list.remove(torpedo)
            self._screen.unregister_torpedo(torpedo)
            del self.asteroids_dic[id]
        else:
            torpedo.lose_life()
            torpedo.set_position()
            self._screen.draw_torpedo(torpedo, torpedo.get_pos_x(), torpedo.get_pos_y(), torpedo.get_angle())


    def asteroid_manager(self, id, asteroid):
        asteroid.set_position()
        self._screen.draw_asteroid(id, asteroid.get_pos_x(), asteroid.get_pos_y())
        if asteroid.has_intersection(self.ship):
            self.ship.lose_life()
            self._screen.unregister_asteroid(id)
            del self.asteroids_dic[id]
            if self.ship.is_dead():
                self._screen.show_message(TITLE, DEAD_MSG)
                sys.exit() # TODO game over?
            else:
                self._screen.show_message(TITLE, LOSE_LIFE_MSG)
                self._screen.remove_life()

    def damaged_asteroid_manager(self, torpedo, id, asteroid):
        for dmg_ast in self.__damaged_asteroids:
            self.add_score(dmg_ast.get_size())
            if dmg_ast.get_size() > MIN_SPLIT_SIZE:
                id = self.__max_asteroid_id + 1
                new_size = dmg_ast.get_size()
                self.asteroids_dic[id] = Asteroid(new_size,
                self.screen_max_x, self.screen_max_y, self.screen_min_x, self.screen_min_y)
                self._screen.register_asteroid(id, new_size)
                id += 1
                new_size = dmg_ast.get_size()
                self.asteroids_dic[id] = Asteroid(new_size,
                self.screen_max_x, self.screen_max_y, self.screen_min_x, self.screen_min_y)
                self._screen.register_asteroid(id, new_size)
                # TODO speed function for split asteroids
                # TODO change the speed and print new asteroids to screen



    def add_score(self, size):
        if size == 3:
            self.__score += 20
        if size == 2:
            self.__score += 50
        if size == 1:
            self.__score += 100


    def _game_loop(self):
        '''
        Your code goes here!
        '''
        self.move_ship()
        if self._screen.is_space_pressed():
            self.create_torpedo()
        for id, asteroid in copy.copy(list(self.asteroids_dic.items())):
            self.asteroid_manager(id, asteroid)
        for torpedo in copy.copy(self.__torpedoes_list):
            self.torpedo_manager(torpedo, id, asteroid)

        self._screen.draw_ship(self.ship.get_pos_x(), self.ship.get_pos_y(), self.ship.get_angle())


def main(amnt):
    runner = GameRunner(amnt)
    runner.run()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        main( int( sys.argv[1] ) )
    else:
        main( DEFAULT_ASTEROIDS_NUM )